/**
 * Corrección específica para el modal de hojas de trabajo
 * Portal del Trabajador - FIX
 */
(function ($) {
  "use strict";

  // Función para corregir problemas del modal
  function fixWorksheetModal() {
    console.log("Aplicando fix para el modal de hojas de trabajo");

    // Comprobar si el modal existe
    if ($("#worksheet-details-modal").length === 0) {
      console.error("Error: Modal de detalles no encontrado en el DOM");
      return;
    }

    // Reemplazar completamente la función de click para ver detalles
    $(document)
      .off("click", ".view-worksheet")
      .on("click", ".view-worksheet", function (e) {
        e.preventDefault();
        e.stopPropagation(); // Prevenir propagación del evento

        const worksheetId = $(this).data("worksheet-id") || $(this).data("id");
        console.log("Click en ver detalles - ID:", worksheetId);

        if (!worksheetId) {
          console.error("Error: No se encontró ID de hoja de trabajo");
          return;
        }

        // Crear un nuevo contenedor modal si el existente falla
        if ($("#emergency-modal").length === 0) {
          const modalHTML = `
          <div id="emergency-modal" style="
            display: none; 
            position: fixed; 
            z-index: 9999; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background-color: rgba(0,0,0,0.4);
          ">
            <div style="
              background-color: #fefefe;
              margin: 10% auto;
              padding: 20px;
              border: 1px solid #888;
              width: 80%;
              max-width: 800px;
            ">
              <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                <h3 style="margin: 0;">Detalles de la Hoja de Trabajo</h3>
                <button id="emergency-modal-close" style="
                  background: none;
                  border: none;
                  font-size: 24px;
                  cursor: pointer;
                ">&times;</button>
              </div>
              <div id="emergency-modal-content"></div>
            </div>
          </div>
        `;
          $("body").append(modalHTML);

          // Añadir evento para cerrar
          $("#emergency-modal-close").on("click", function () {
            $("#emergency-modal").hide();
          });

          // Cerrar con clic fuera o ESC
          $(document).on("click", function (e) {
            if ($(e.target).is("#emergency-modal")) {
              $("#emergency-modal").hide();
            }
          });

          $(document).on("keydown", function (e) {
            if (e.key === "Escape" && $("#emergency-modal").is(":visible")) {
              $("#emergency-modal").hide();
            }
          });
        }

        // Mostrar cargador
        $("#emergency-modal-content").html(
          '<div style="text-align: center; padding: 20px;">' +
            '<div style="display: inline-block; border: 4px solid #f3f3f3; border-top: 4px solid #2271b1; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin-bottom: 10px;"></div>' +
            "<p>Cargando detalles...</p>" +
            "</div>"
        );
        $("#emergency-modal").show();

        // Cargar datos via AJAX
        $.ajax({
          url: ajaxurl,
          type: "POST",
          data: {
            action: "admin_get_worksheet_details",
            nonce: $("#admin_nonce").val(),
            worksheet_id: worksheetId,
          },
          success: function (response) {
            console.log("Datos recibidos:", response);

            if (response.success) {
              // Insertar contenido
              $("#emergency-modal-content").html(response.data);

              // Reactivar botón de validar si existe
              $("#emergency-modal-content .validate-worksheet").on(
                "click",
                function () {
                  const id = $(this).data("worksheet-id") || $(this).data("id");
                  if (id) {
                    if (
                      confirm("¿Estás seguro de validar esta hoja de trabajo?")
                    ) {
                      $.ajax({
                        url: ajaxurl,
                        type: "POST",
                        data: {
                          action: "admin_validate_worksheet",
                          nonce: $("#admin_nonce").val(),
                          worksheet_id: id,
                        },
                        success: function (resp) {
                          if (resp.success) {
                            alert(
                              resp.data.message || "Hoja validada correctamente"
                            );
                            $("#emergency-modal").hide();
                            // Recargar la lista de hojas
                            if (
                              typeof WorkerPortalAdminFrontend !==
                                "undefined" &&
                              typeof WorkerPortalAdminFrontend.loadWorksheets ===
                                "function"
                            ) {
                              WorkerPortalAdminFrontend.loadWorksheets();
                            } else {
                              window.location.reload();
                            }
                          } else {
                            alert(resp.data || "Error al validar la hoja");
                          }
                        },
                        error: function () {
                          alert("Error de comunicación con el servidor");
                        },
                      });
                    }
                  }
                }
              );
            } else {
              $("#emergency-modal-content").html(
                '<div style="color: #d63638; padding: 15px; background-color: #fcf0f1; border-left: 4px solid #d63638;">' +
                  (response.data || "Error al cargar los detalles") +
                  "</div>"
              );
            }
          },
          error: function (xhr, status, error) {
            console.error("Error AJAX:", xhr, status, error);
            $("#emergency-modal-content").html(
              '<div style="color: #d63638; padding: 15px; background-color: #fcf0f1; border-left: 4px solid #d63638;">' +
                "Error de comunicación con el servidor. Por favor, inténtalo de nuevo." +
                "</div>"
            );
          },
        });
      });

    // Crear estilos para la animación de carga
    const styleElement = document.createElement("style");
    styleElement.textContent = `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(styleElement);

    console.log("Fix para modal aplicado correctamente");
  }

  // Aplicar la corrección cuando el DOM esté listo
  $(document).ready(function () {
    // Esperar un poco para asegurar que todo está cargado
    setTimeout(fixWorksheetModal, 1000);
  });

  // También aplicar cuando se carguen hojas de trabajo
  $(document).on("ajaxSuccess", function (event, xhr, settings) {
    if (
      settings.data &&
      (settings.data.indexOf("admin_load_worksheets") > -1 ||
        settings.data.indexOf("filter_worksheets") > -1)
    ) {
      setTimeout(fixWorksheetModal, 500);
    }
  });
})(jQuery);
